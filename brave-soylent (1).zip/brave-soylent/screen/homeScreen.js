import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    Platform,
    StatusBar,
    Image,
    ScrollView,
    TextInput,
     TouchableOpacity,
     Header
} from "react-native";
import AppHeader from "../components/AppHeader"

export default class HomeSreen extends Component{
  render(){
    return(<AppHeader/>
     
    )
  }
}