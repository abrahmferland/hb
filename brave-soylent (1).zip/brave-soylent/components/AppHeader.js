import*as React from 'react'
import {Text,
        View,
        StyleSheet
        }
from 'react-native'
export default class AppHeader extends React.Component{
  render(){
    return(
      <View style={styles.textContaner}>
      <Text style={styles.text}>
      you look at you phone to much app
      </Text>
      </View>
    )
  }
}
const styles = StyleSheet.create({
  textContaner:{
    backgroundColor: "black"  
  },
  text:{
  color:"white",
  fontSize:30,
  fontWeight:"bold",
textAlign:"center"

  }
})
